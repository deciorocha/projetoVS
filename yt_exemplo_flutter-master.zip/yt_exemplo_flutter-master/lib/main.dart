import 'package:exemplo/app/definition.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(Definition());
}



 import 'package:exemplo/app/domain/model/contact.dart';

List<Contact> lista =  [
  Contact(nome: 'Pietro', telefone: '(11) 9 8456-8526', foto: 'https://cdn.pixabay.com/photo/2016/11/18/23/38/child-1837375_960_720.png'),
  Contact(nome: 'Maitê', telefone: '(11) 9 9778-1112', foto: 'https://cdn.pixabay.com/photo/2020/12/23/14/26/woman-5855148_960_720.png'),
  Contact(nome: 'Hortência', telefone: '(11) 9 9988-6523', foto: 'https://cdn.pixabay.com/photo/2021/01/06/08/44/woman-5893618_960_720.png'),
  Contact(nome: 'Aldo', telefone: '(11) 9 9526-7575', foto: 'https://cdn.pixabay.com/photo/2018/08/28/12/41/avatar-3637425_960_720.png'),
];

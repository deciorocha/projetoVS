class Contact{
  String nome; 
  String telefone; 
  String foto;

  Contact({this.nome, this.telefone, this.foto});
}
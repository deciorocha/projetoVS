package br.com.helio.exemplo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
